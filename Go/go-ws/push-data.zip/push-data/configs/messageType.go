package configs

type MessageType struct {
	msgType string
	msgData string
}
