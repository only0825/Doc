package task

import "context"

var ctx = context.Background()
