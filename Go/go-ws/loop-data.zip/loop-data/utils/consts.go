package utils

const (
	Football   = 1
	BasketBall = 2
)
